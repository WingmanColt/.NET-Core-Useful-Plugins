using System;

namespace ViewModels
{ 
    public class SelectListModel
    {
        public String Text { get; set; }
        public String Value { get; set; }
    }
}