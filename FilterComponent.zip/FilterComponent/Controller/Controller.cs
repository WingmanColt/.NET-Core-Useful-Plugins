﻿using ViewModels;
using Views;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Controller
{
    public class Controller : BaseController
    {

        public JobsController()
        {

        }

        [HttpGet]
        [Route("jobs/all")]
        public async Task<IActionResult> Index(Filter filter, int currentPage = 1, int categoryid = 0, List<CheckBoxListItem> Equipments = null, List<CheckBoxListItem> Salaries = null, string Internship = null)
        {
            // Init selectlist items; Just get items from db 
            var viewModel = new JobsViewModel
            {
                AllLocations = _locationService.GetAllSelectList(),
                AllCategories = _categoriesService.GetAllSelectList()
                
            };
            viewModel.Skills = _skillsService.GetAll<Skills>(viewModel.TagsId, false);

             if(Equipments.Capacity > 0)
             filter.Equipments = Equipments;

            var entity = GetAllJobsAsNoTracking()
                .Select(x => new Jobs
                {
                    Id = x.Id,
                    Name = x.Name,
                    WorkType = x.WorkType,
                    LocationId = x.LocationId,
                    CreatedOn = x.CreatedOn,
                    PosterID = x.PosterID,
                    RatingVotes = x.RatingVotes,
                    Promotion = x.Promotion,
                    Adress = x.Adress,
                    JobType = x.JobType,
                    MinSalary = x.MinSalary,
                    MaxSalary = x.MaxSalary,
                    SalaryType = x.SalaryType,
                    CompanyId = x.CompanyId,
                    CategoryId = x.CategoryId,
                    TagsId = x.TagsId                  
                });

            if (!String.IsNullOrEmpty(filter.SearchString))
            {
                entity = entity.Where(x => x.Name.Contains(filter.SearchString));
            }

            if (!String.IsNullOrEmpty(filter.TagsId))
            {
                string[] tags = filter.TagsId?.Split(", ");
                entity = entity.Where(x => ((IList)tags).Contains(x.TagsId));
            }

            if (!String.IsNullOrEmpty(filter.LanguageId))
            {
                string[] langs = filter.LanguageId?.Split(", ");
                entity = entity.Where(x => ((IList)langs).Contains(x.LanguageId));
            }
            if (filter.Equipments?.Capacity > 0)
            {
                foreach (var item in filter.Equipments)
                {
                    if (item.IsChecked)
                        entity = entity.Where(x => x.WorkType.Contains(item.Value));
                }
            }
            if (filter.Salaries?.Capacity > 0)
            {
                foreach (var item in filter.Salaries)
                {
                    if (item.IsChecked)
                        entity = entity.Where(x => x.MinSalary >= item.intValue);
                }
            }
            if (!String.IsNullOrEmpty(filter.LocationId))
            {
                entity = entity.Where(s => s.LocationId.Equals(filter.LocationId));
            }
            if (filter.CategoryId > 0)
            {
                entity = entity.Where(x => x.CategoryId == filter.CategoryId);
            }
            if (categoryid > 0)
                entity = entity.Where(x => x.CategoryId == categoryid);

            if (!String.IsNullOrEmpty(Internship))
            {
                entity = entity.Where(s => s.WorkType.Contains("Подходяща за начинаещи"));
            }
            switch (filter.Sort)
            {
                case "Рейтинг":
                    entity = entity.OrderByDescending(x => x.RatingVotes);
                    break;
                case "Последни":
                    entity = entity.OrderBy(x => x.CreatedOn);
                    break;
                case "Най-нови":
                    entity = entity.OrderByDescending(x => x.CreatedOn);
                    break;
                case "Заплата":
                    entity = entity.OrderBy(x => x.MaxSalary);
                    break;
                default:
                    entity = entity.OrderByDescending(x => x.CreatedOn);
                    break;
            }

            if (await entity.AnyAsync()) // prevent 'SqlException: The offset specified in a OFFSET clause may not be negative.'
            {
                int count = await entity.AsQueryable().AsNoTracking().CountAsync().ConfigureAwait(false);
                viewModel.Pager = new Pager(count, currentPage);

                var result = entity
                .Skip((viewModel.Pager.CurrentPage - 1) * viewModel.Pager.PageSize)
                .Take(viewModel.Pager.PageSize);

                viewModel.Result = result.To<JobsViewModel>().AsAsyncEnumerable();
            }
            else viewModel.Result = null;

            return View(viewModel);
        }

     
    }

    // External
    // Example for category, locations, skills, etc services and getting all.

    // #1 Category; You can use same principe for others.
    public IAsyncEnumerable<SelectListModel> GetAllSelectList()
    {
        var result = GetAllAsNoTracking()
                .Select(x => new SelectListModel
                {
                    Value = x.Id.ToString(),
                    Text = x.Title
                })
                .ToAsyncEnumerable();

        return result;
    }
    public IQueryable<Category> GetAllAsNoTracking()
    {
        return categoriesRepository.Set().AsNoTracking();
    }

    // END Category service



    // Getting all jobs; move on external service !!!
    public IQueryable<Jobs> GetAllJobsAsNoTracking()
    {
        return jobsRepository.Set().AsQueryable().AsNoTracking();
    }

}