﻿using HireMe.Entities.View;
using HireMe.Entities;
using HireMe.Entities.Enums;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace ViewComponents
{
    [ViewComponent(Name = "_Filter")]
    public class _FilterViewComponent : ViewComponent
    {
        public _FilterViewComponent()
        {
        }

        public async Task<IViewComponentResult> InvokeAsync()
        {
        var model = new Filter();

        model.Equipments = Enum.GetValues(typeof(WorkType))
        .Cast<WorkType>()
        .Select(t => new CheckBoxListItem
        {
            Key = ((int)t),
            Value = t.GetDisplayName()
        }).ToList();


            return View(model);           
        }

    }
}